# Web-клиент (архив v1)

> **Архив.** Актуальное описание — [web-client.md](./web-client.md). Этот файл описывает предыдущий v1-клиент в `frontend/`.

Web-клиент TG Platform — production frontend платформы: полноценный интерфейс для ленты, постов, чатов, заметок, аналитики и профиля канала.

**Фаза разработки:** local-first — in-memory store, seed-данные, локальные ответы ИИ вместо реального API. Это временное ограничение клиента, не определение продукта. Backend и интеграции — по [08-roadmap.md](../product/08-roadmap.md).

---

## Зачем отдельный документ

- Зафиксировать, что именно реализовано в `Docs_TG_Platform/web/` и как это соотносится с концептом.
- Описать границу «работает в браузере» vs «требует сервер».
- Дать оценщику и контрибьютору точку входа рядом с [pages.md](../ux/pages.md) и wireframes.

---

## Где живёт код

- **Исходники (актуальный клиент):** `Docs_TG_Platform/frontend/`
- **Архив (reference only):** `Docs_TG_Platform/web-legacy/`
- **Стек:** Next.js 16 (App Router) + React 19 + TypeScript + Tailwind v4 + shadcn/ui, Feature-Sliced Design
- **Сборка:** статический экспорт → `frontend/out/`
- **Документация кода:** [`frontend/ARCHITECTURE.md`](../frontend/ARCHITECTURE.md), [`frontend/PRODUCT.md`](../frontend/PRODUCT.md)

Технические свойства клиента:

- static export — без Node-сервера в prod;
- CSS: `src/app/styles/` (globals + экранные файлы);
- глобальное состояние — React Context + reducers в `src/app/model/store/`;
- seed-данные — `src/shared/data/seed-data.ts`.

---

## Что реализовано в интерфейсе

Web-клиент отражает текущую модель платформы:

- лента постов с тремя секциями (`Опубликованные / Отложенные / Черновики`) и поиском;
- пространство поста с режимами `chat` / `chats` / `notes` / `comments` и стеком переходов;
- комментарии к опубликованным постам;
- сайдбар с недавними чатами/заметками и сворачиваемым rail;
- глобальный чат (`home` + `gchat`);
- каталог чатов и заметок с фильтрами и поиском;
- аналитика канала;
- профиль (`Канал` / `Настройки` / `Аналитика платформы`).

Интерактивное поведение фронта включает drag-and-drop черновиков и embed в заметках, inline-редактирование поста, ветки сообщений, composer с ModelPicker и AttachMenu, единую шапку PageHeader, переключатель темы.

Детальное описание экранов — в [pages.md](../ux/pages.md).

---

## Чего клиент пока не делает (local-first)

- не публикует реальные посты в Telegram;
- не вызывает реальные LLM (ответы — seed / keyword rules);
- не сохраняет состояние между перезагрузками вкладки (до backend);
- не реализует prod-auth, права доступа, синхронизацию.

---

## Стартовое состояние

При первом открытии загружаются seed-данные:

- заполненный профиль канала;
- посты во всех трёх секциях ленты с метриками и комментариями;
- глобальные и локальные заметки;
- сохранённые чаты;
- мок-модели в настройках;
- seed-метрики аналитики.

---

## Локальные ответы ИИ (временно)

До подключения API ответы подставляются по правилам:

- `src/shared/lib/replies.ts` — `getGlobalReply`, `getPostReply` (ключевые слова);
- `src/shared/lib/chatPaths.ts` — `STUB_REPLY_AFTER_USER_EDIT` после правки сообщения.

| Контекст | Ключевые слова | Тема |
|----------|----------------|------|
| Глобальный ИИ | `контент-план`, `рубрик`, `тем`, `охват` | стратегия канала |
| Локальный ИИ | `перепиш`/`rewrite`, `заголов`, `почему`/`аналити` | работа с постом |

---

## Архитектура (кратко)

```
src/
├── app/           # Next.js routes, store, styles
├── screens/       # экраны (FSD)
├── widgets/       # sidebar, composer, post-workspace, …
├── features/      # post-context-menu, schedule-post, …
├── entities/      # post, message, …
└── shared/        # ui, lib, types, seed data
```

Подробнее — [architecture.md](./architecture.md) (актуальный web) или [`frontend/ARCHITECTURE.md`](../../../frontend/ARCHITECTURE.md) (v1).

---

## Связь с концептом и roadmap

- Клиент иллюстрирует модель из [01-essence.md](../product/01-essence.md), [02-modules.md](../product/02-modules.md), [03-spaces.md](../product/03-spaces.md).
- [08-roadmap.md](../product/08-roadmap.md) — фазы **backend и интеграций**; UI уже опережает часть roadmap.
- При изменении [pages.md](../ux/pages.md) web-клиент обновляется следом.

---

## Публичный preview

Статическая сборка может публиковаться на GitHub Pages для preview без установки — это **деploy web-клиента**, не отдельный «демо-продукт». Meta и README описывают TG Platform как продукт; local-first — фаза разработки.

---

## Критерии готовности UI-слоя

- все экраны из [pages.md](../ux/pages.md) доступны;
- seed-состояние согласовано с [02-modules.md](../product/02-modules.md);
- ответы ИИ не ломают интерфейс на произвольный ввод;
- `npm run build` в `web/` проходит без ошибок.
